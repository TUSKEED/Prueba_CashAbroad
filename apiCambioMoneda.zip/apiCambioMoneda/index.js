//Importamos express y json web token para la seguridad
import express from "express";
import jwt from "jsonwebtoken";

const app = express();
const port = 3000;
const secretKey = "secretkey";

var usdToMxn;

app.use(express.json());

//Creamos una constante con la la dirección de la api de donde obtendremos el cambio en tiempo real de la divisa
const url = "https://v6.exchangerate-api.com/v6/3590c99380c1c89ccd9bb5cd/latest/USD";
fetch(url)
    .then(respuesta => {
        if (!respuesta.ok) {
            console.log('No se ha podido recuperar la información');
        }
        return respuesta.json();
    })
    .then(respuesta => {
        usdToMxn = respuesta.conversion_rates.MXN
    })
    .catch(err => {
        console.log(err);
    })


//Iniciamos el servidor y definimos el puerto
app.listen(port,() => {
    console.log(`Eschuchando desde el puerto ${port}`);
});
//Deifinimos la ruta por defecto
app.get('/', (req, res) => {
    res.send('Api de cambio de monedas')
})

//Endpoint para la autenticación y generación del token
app.post('/login', (req, res) => {
    // Aquí debemos validar las credenciales del usuario, por simplicidad, lo omitiremos
    const { username } = req.body;

    // Generamos un token JWT con el nombre de usuario y la clave secreta
    const token = jwt.sign({ username }, secretKey, { expiresIn: '1h' });
    res.json({ token });
});

//Función para verificar el token
function verification(req, res, next) {
    //extraemos el token del encabezado de authorización 
    const token = req.headers.authorization && req.headers.authorization.split(' ')[1];

    //Verificamos si el token está presente
    if (!token){
        return res.status(401).json({ message: 'Token no proporcionado' });
    }
    //Verificamos el token pasando el mismo y la palabra clave y una función callback para manejar el resultado de la verificación
    jwt.verify(token, secretKey, (err, decoded) => {
        if (err) {
            return res.status(403).json({ message: 'Token inválido' });
        }
        //Si es valido lo decodificamos y almacenamos en decoded
        req.user = decoded;
        // Llamamos a la función "next()" para pasar el control al siguiente middleware
        next();
    });
}
//Definimos que al realizar una solicitud de tipo post en la ruta cambio se lleva a cabo la conversión de pesos a dolares y viceversa.
//Aqui recuperaremos la moneda y la cantidad que deseamos convertir.
app.post('/cambio',verification, (req, res) => {
    const {mxn, usd} = req.body;
    if (mxn != null && usd == null) {
        var total = mxn / usdToMxn;
        res.send(`La conversión de ${mxn} pesos mexicanos a dolares americanos es de ${total}`);
    } else if (usd != null && mxn == null) {
        var total = usd * usdToMxn;
        res.send(`La conversión de ${usd} dolares americanos a pesos mexicanos es de ${total}`);
    } else {
        res.send(`Por favor seleccione una moneda e ingrese una cantidad.`);
    }
});