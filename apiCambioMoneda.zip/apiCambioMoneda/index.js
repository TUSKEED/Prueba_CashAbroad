//Importamos expres
import express from "express";
//Creamos una variable que almacenará el valor de pesos mexicanos a dolares
var usdToMxn;
//Creamos una constante con la la dirección de la api de donde obtendremos el cambio en tiempo real de la divisa
const url = "https://v6.exchangerate-api.com/v6/3590c99380c1c89ccd9bb5cd/latest/USD";
//Realizamos la petición de tipo get a la previa dirección de la api.
fetch(url)
//Corroboramos que la petición sea exitosa y parseamos la respuesta a json
.then(respuesta => {
    if (!respuesta.ok) {
        console.log("No se ha podido recuperar la información")
    }
    return respuesta.json();
})
//Recuperamos el valor de la divisa y la almacenamos en nuestra variable
.then(respuesta => {
    usdToMxn = respuesta.conversion_rates.MXN
})
//Creamos un catch en caso de que surga algun error, se capture y nos notifique por consola
.catch(err => {
    console.log(err);
})

//Creamos la constante con la que usaremos express
const app = express();
//Declaramos el puerto en el que nuestra api correrá
const port = 3000;
//Habilitamos el análisis del cuerpo de las solicitudes con formato JSON
app.use(express.json());

//Iniciamos el servidor y definimos el puerto
app.listen(port,() => {
    console.log(`Eschuchando desde el puerto ${port}`);
});
//Deifinimos que al recibir una solicitud get en la ruta por defecto unicamente mostraremos el siguiente mensaje
app.get('/', (req, res) => {
    res.send("Api de cambio de monedas")
})
//Definimos que al realizar una solicitud de tipo post en la ruta cambio se lleva a cabo la conversión de pesos a dolares y viceversa.
//Aqui recuperaremos la moneda y la cantidad que deseamos convertir.
app.post('/cambio', (req, res) => {
    const {mxn, usd} = req.body;
    if (mxn != null && usd == null) {
        var total = mxn / usdToMxn;
        res.send(`La conversión de ${mxn} pesos mexicanos a dolares americanos es de ${total}`);
    } else if (usd != null && mxn == null) {
        var total = usd * usdToMxn;
        res.send(`La conversión de ${usd} dolares americanos a pesos mexicanos es de ${total}`);
    } else {
        res.send(`Por favor seleccione una moneda e ingrese una cantidad.`);
    }
});